<?php
include "classes/db.classes.php";
$db = new DB();
$results = $db->insertMKData();
?>